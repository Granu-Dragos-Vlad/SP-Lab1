package TestLab;

import java.util.List;

public class SubComanda extends Comanda implements Element {
	private Integer id;

	public SubComanda(Integer id) {
		super();
		this.id = id;
	}

	@Override
	public String toString() {
		return "SubComanda [id=" + id + "]";
	}

	public void accept(Visitor a) {
		a.visitSubComanda(this);
	}

}
