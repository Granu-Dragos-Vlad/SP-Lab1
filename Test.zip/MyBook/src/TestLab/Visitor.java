package TestLab;

public interface Visitor {
	void visitPizza(Pizza a);
	void visitPaste(Paste a);
	void visitSalata(Salata a);
	void visitComanda(Comanda a);
	void visitSubComanda(SubComanda a);
	
}
