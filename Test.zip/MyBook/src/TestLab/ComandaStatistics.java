package TestLab;

public class ComandaStatistics implements Visitor {
	private Integer costPizza;
	private Integer costPaste;
	private Integer costSalata;

	@Override
	public void visitPizza(Pizza a) {
		this.costPizza=this.costPizza+a.getPret();

	}

	@Override
	public void visitPaste(Paste a) {
		this.costPaste=this.costPaste+a.getPret();

	}

	@Override
	public void visitSalata(Salata a) {
	     this.costSalata=this.costSalata+a.getPret();

	}

	@Override
	public void visitComanda(Comanda a) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visitSubComanda(SubComanda a) {
		// TODO Auto-generated method stub

	}
	public void printStatistics()
	{
	    Integer pretcomanda=this.costPizza+this.costPaste+this.costSalata;
		System.out.println("Pretul total pentru pizza este : "+this.costPizza);
		System.out.println("Pretul total pentru paste este : "+this.costPaste);
		System.out.println("Pretul total pentru salate este : "+this.costSalata);
		System.out.println("Pretul total al comenzii este: "+pretcomanda);
		
	}

}
