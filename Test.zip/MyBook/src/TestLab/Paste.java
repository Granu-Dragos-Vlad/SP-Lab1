package TestLab;

public class Paste implements Element {
	private String nume;
	private Integer pret;

	public Paste(String nume, Integer pret) {

		this.nume = nume;
		this.pret = pret;
	}

	public String getNume() {
		return nume;
	}

	public void setNume(String nume) {
		this.nume = nume;
	}

	public Integer getPret() {
		return pret;
	}

	public void setPret(Integer pret) {
		this.pret = pret;
	}

	@Override
	public void add(Element e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void remove(Element e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void print() {
		System.out.println("Numele felului de paste este: " + this.nume + " ,iar pretul acesteia este: " + this.pret);

	}

	@Override
	public Element get(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void accept(Visitor a) {
		a.visitPaste(this);
		// TODO Auto-generated method stub

	}

}
