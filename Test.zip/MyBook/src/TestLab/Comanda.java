package TestLab;

import java.util.ArrayList;
import java.util.List;

public class Comanda implements Element {
	private Integer idComanda;
	private List<Element> elemente = new ArrayList<>();

	public Comanda(Integer idComanda, List<Element> elemente) {
		this.idComanda = idComanda;
		this.elemente = elemente;
	}

	public Comanda() {
	};

	@Override
	public void add(Element e) {
		this.elemente.add(e);

	}

	@Override
	public void remove(Element e) {
		this.elemente.remove(e);

	}

	@Override
	public void print() {
		System.out.println("Id-ul comenzii este :" + this.idComanda);
		for (Element a : elemente) {
			a.print();
		}

	}

	@Override
	public Element get(int index) {
		if (index <= this.elemente.size()) {
			return this.elemente.get(index);
		} else
			return null;
	}

	@Override
	public void accept(Visitor a) {
		a.visitComanda(this);
		for (Element e : elemente) {
			e.accept(a);
		}

	}

}
