package TestLab;

public interface Element {
	void add(Element e);

	void remove(Element e);

	void print();

	Element get(int index);

	void accept(Visitor a);

}
